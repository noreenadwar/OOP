package sample;

import java.util.Date;

    public class Book extends Content{
        public Book(String ContentName, String Barcode, Date dateBought, Date dateRented, double price ){
            super(ContentName,Barcode,dateRented,price);

        }

        @Override
        public void displayContent() {
            super.displayContent();
        }
    }

