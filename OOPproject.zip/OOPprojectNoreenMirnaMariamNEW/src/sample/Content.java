package sample;
import java.util.Date;

    public class Content implements Library {
        protected String ContentName;
        protected String Barcode;
        protected Date dateRented;
        protected double price;

        public Content(String ContentName, String Barcode, Date dateRented, double price) {
            this.ContentName = ContentName;
            this.Barcode = Barcode;
            this.dateRented = dateRented;
            this.price = price;
        }

        @Override
        public void display() {

        }

        @Override
        public void displayContent() {
            System.out.println("Name of Book or Magazine:" + ContentName);
            System.out.println("Barcode:" + Barcode);
            System.out.println("Date of renting:" + dateRented);
        }

        public String getContentName() {
            return ContentName;
        }

        public void setContentName(String contentName) {
            ContentName = contentName;
        }

        public String getBarcode() {
            return Barcode;
        }

        public void setBarcode(String barcode) {
            Barcode = barcode;
        }

        public Date getDateRented() {
            return dateRented;
        }

        public void setDateRented(Date dateRented) {
            this.dateRented = dateRented;
        }
    }



