package sample;

public class Customer extends Person {
        private int BooksRented;
        private double totalAmount;
        private int MagazinesRented;


        public Customer(String Name, int ID, String TelephoneNumber, String address) {
            super(Name, ID, TelephoneNumber, address);
            this.BooksRented = 0;
            this.MagazinesRented = 0;
        }

        @Override
        public void display() {
            super.display();
            System.out.println("Books Rented:" + BooksRented);
            System.out.println("Magazines Rented" + MagazinesRented);
        }

        public void rent(Magazine m) {

            totalAmount = totalAmount + m.price;
            MagazinesRented ++;
        }
        public void rent(Magazine m[]){
            for(int i=0; i<m.length;i++){
                totalAmount = totalAmount + m[i].price;
                MagazinesRented++;
            }
        }

        public void rent(Book b) {
            totalAmount = totalAmount + b.price;
            BooksRented++;
        }

        public void rent(Book b[]) {
            for (int i = 0; i < b.length; i++) {
                totalAmount = totalAmount + b[i].price;
                BooksRented++;
            }
        }

        public int getBooksRented() {
            return BooksRented;
        }

        public void setBooksRented(int booksRented) {
            BooksRented = booksRented;
        }

        public int getMagazinesRented() {
            return MagazinesRented;
        }

        public void setMagazinesRented(int magazinesRented) {
            MagazinesRented = magazinesRented;
        }

        public double gettotalAmount(){ return totalAmount;}

        public void setTotalAmount(double totalAmount){totalAmount = totalAmount;}



    }


