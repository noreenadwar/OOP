package sample;

import java.util.Date;

    public class Magazine extends Content{
        public Magazine(String ContentName, String Barcode, Date dateBought, Date dateRented,double price){
            super(ContentName,Barcode,dateRented,price);

        }

        @Override
        public void displayContent() {
            super.displayContent();
        }
    }


