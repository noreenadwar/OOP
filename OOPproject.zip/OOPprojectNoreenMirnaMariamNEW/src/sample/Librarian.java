package sample;


    public class Librarian extends Person{
        private double LIBsalary;
        private int EmploymentYears;
        private int Overtime;


        public Librarian(double LIBsalary, int EmploymentYears, int Overtime,String Name, int ID,String TelephoneNumber, String address){
            super(Name,ID,TelephoneNumber, address);
            this.LIBsalary=LIBsalary;
            this.EmploymentYears=EmploymentYears;
            this.Overtime=Overtime;
        }

        @Override
        public void display() {
            super.display();
            System.out.println("Librarian Salary:"+LIBsalary);
            System.out.println("Employment Years:"+EmploymentYears);
            System.out.println("Overtime hours:"+Overtime);
        }

        public double getLIBsalary() {
            return LIBsalary;
        }

        public void setLIBsalary(double LIBsalary) {
            this.LIBsalary = LIBsalary;
        }

        public int getEmploymentYears() {
            return EmploymentYears;
        }

        public void setEmploymentYears(int employmentYears) {
            EmploymentYears = employmentYears;
        }

        public int getOvertime() {
            return Overtime;
        }

        public void setOvertime(int overtime) {
            Overtime = overtime;
        }
    }



