package sample;

    public class Person implements Library{
        protected String Name;
        protected int ID;
        protected String TelephoneNumber;
        protected String address;




        public Person(String Name, int ID,String TelephoneNumber, String address) {
            this.Name=Name;
            this.ID=ID;
            this.address=address;
            this.TelephoneNumber=TelephoneNumber;
        }

        @Override
        public void display(){
            System.out.println("Name:"+Name);
            System.out.println("ID:"+ID);
            System.out.println("Telephone Number:"+TelephoneNumber);
            System.out.println("Address:"+address);
        }

        @Override
        public void displayContent() {

        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            Name = name;
        }

        public int getID() {
            return ID;
        }

        public void setID(int ID) {
            this.ID = ID;
        }

        public String getTelephoneNumber() {
            return TelephoneNumber;
        }

        public void setTelephoneNumber(String telephoneNumber) {
            TelephoneNumber = telephoneNumber;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }






    }


