package sample;


    public interface Library {
        void display();
        void displayContent();

    }


