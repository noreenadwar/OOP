package sample;

    public class Manager extends Person{
        private double ManSalary;

        public Manager(double ManSalary,String Name, int ID,String TelephoneNumber, String address ){
            super(Name,ID,TelephoneNumber, address);
            this.ManSalary=ManSalary;
        }

        @Override
        public void display() {
            super.display();
            System.out.println("Manager Salary:"+ManSalary);
        }

        public double getManSalary() {
            return ManSalary;
        }

        public void setManSalary(double manSalary) {
            ManSalary = manSalary;
        }
    }


